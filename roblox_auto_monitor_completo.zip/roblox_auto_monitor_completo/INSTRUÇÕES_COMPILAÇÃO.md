# 🛠️ Instruções Detalhadas de Compilação - Roblox Auto Monitor

## 📋 Pré-requisitos

### 1. Instalar Flutter SDK

#### Windows:
1. Baixe o Flutter SDK: https://docs.flutter.dev/get-started/install/windows
2. Extraia para `C:\flutter`
3. Adicione `C:\flutter\bin` ao PATH do sistema

#### macOS:
```bash
# Usando Homebrew
brew install flutter

# Ou baixe manualmente
curl -O https://storage.googleapis.com/flutter_infra_release/releases/stable/macos/flutter_macos_3.24.5-stable.zip
unzip flutter_macos_3.24.5-stable.zip
export PATH="$PATH:`pwd`/flutter/bin"
```

#### Linux:
```bash
# Baixar e extrair Flutter
wget https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.24.5-stable.tar.xz
tar xf flutter_linux_3.24.5-stable.tar.xz
export PATH="$PATH:`pwd`/flutter/bin"

# Adicionar ao .bashrc permanentemente
echo 'export PATH="$PATH:/path/to/flutter/bin"' >> ~/.bashrc
```

### 2. Instalar Android Studio

1. **Baixe Android Studio**: https://developer.android.com/studio
2. **Instale com configurações padrão**
3. **Abra Android Studio** e complete o setup inicial
4. **Instale Android SDK** (será solicitado automaticamente)

### 3. Configurar Android SDK

#### Via Android Studio:
1. Abra **Tools > SDK Manager**
2. Instale **Android SDK Platform-Tools**
3. Instale **Android SDK Build-Tools** (versão 34.0.0 ou superior)
4. Instale **Android API 34** (ou superior)

#### Via Linha de Comando:
```bash
# Configurar variáveis de ambiente
export ANDROID_HOME=$HOME/Android/Sdk  # Linux/macOS
# ou
set ANDROID_HOME=C:\Users\%USERNAME%\AppData\Local\Android\Sdk  # Windows

export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools

# Instalar componentes necessários
sdkmanager "platforms;android-34"
sdkmanager "build-tools;34.0.0"
sdkmanager "platform-tools"
```

### 4. Instalar Java 17

#### Windows:
1. Baixe OpenJDK 17: https://adoptium.net/
2. Instale e configure JAVA_HOME
3. Configure Flutter: `flutter config --jdk-dir="C:\Program Files\Eclipse Adoptium\jdk-17.0.x"`

#### macOS:
```bash
# Usando Homebrew
brew install openjdk@17
export JAVA_HOME=/opt/homebrew/opt/openjdk@17
flutter config --jdk-dir=$JAVA_HOME
```

#### Linux:
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install openjdk-17-jdk

# Configurar Flutter
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
flutter config --jdk-dir=$JAVA_HOME
```

## 🔧 Preparação do Projeto

### 1. Verificar Instalação
```bash
flutter doctor
```
**Resultado esperado:**
- ✅ Flutter (Channel stable)
- ✅ Android toolchain
- ⚠️ Chrome, Linux toolchain (não necessários para Android)
- ⚠️ Android Studio (pode mostrar aviso, mas não impede compilação)
- ✅ Connected device

### 2. Aceitar Licenças Android
```bash
flutter doctor --android-licenses
```
Digite `y` para aceitar todas as licenças.

### 3. Preparar Código Fonte
```bash
# Navegue até o diretório do projeto
cd roblox_auto_monitor

# Instale dependências
flutter pub get
```

## 🚀 Compilação

### 1. Compilação de Debug (para testes)
```bash
flutter build apk --debug
```
**Localização:** `build/app/outputs/flutter-apk/app-debug.apk`

### 2. Compilação de Release (versão final)
```bash
flutter build apk --release
```
**Localização:** `build/app/outputs/flutter-apk/app-release.apk`

### 3. Compilação com Otimizações
```bash
# APK otimizado (menor tamanho)
flutter build apk --release --shrink

# Bundle AAB (para Google Play Store)
flutter build appbundle --release
```

## 🔧 Resolução de Problemas

### Erro: "Namespace not specified"
**Solução:**
```bash
flutter clean
flutter pub get
flutter pub upgrade
```

### Erro: "Java version conflict"
**Solução:**
```bash
# Verificar versão Java
java -version

# Configurar Flutter para usar Java 17
flutter config --jdk-dir=/path/to/java17
```

### Erro: "Android licenses not accepted"
**Solução:**
```bash
flutter doctor --android-licenses
# Digite 'y' para todas as licenças
```

### Erro: "SDK not found"
**Solução:**
```bash
# Verificar ANDROID_HOME
echo $ANDROID_HOME  # Linux/macOS
echo %ANDROID_HOME%  # Windows

# Configurar se necessário
export ANDROID_HOME=/path/to/android/sdk
flutter config --android-sdk /path/to/android/sdk
```

### Erro: "Gradle build failed"
**Solução:**
```bash
# Limpar cache Gradle
cd android
./gradlew clean  # Linux/macOS
gradlew.bat clean  # Windows

# Voltar ao diretório raiz e tentar novamente
cd ..
flutter clean
flutter pub get
flutter build apk --release
```

### Erro: "Plugin compatibility"
**Solução:**
```bash
# Atualizar dependências
flutter pub upgrade

# Se persistir, editar pubspec.yaml e usar versões específicas
```

## 📱 Instalação no Dispositivo

### 1. Habilitar Instalação de Fontes Desconhecidas
1. Vá em **Configurações > Segurança**
2. Ative **"Fontes desconhecidas"** ou **"Instalar apps desconhecidos"**

### 2. Transferir APK
```bash
# Via ADB (se dispositivo conectado via USB)
adb install build/app/outputs/flutter-apk/app-release.apk

# Ou copie o arquivo APK para o dispositivo e instale manualmente
```

### 3. Conceder Permissões
Após instalação:
1. Abra o aplicativo
2. Conceda permissões quando solicitado
3. Vá em **Configurações > Apps > Acesso Especial > Estatísticas de Uso**
4. Ative para **"Roblox Auto Monitor"**

## 🎯 Otimizações de Compilação

### Reduzir Tamanho do APK
```bash
# Usar ProGuard/R8
flutter build apk --release --obfuscate --split-debug-info=debug-info/

# Gerar APKs separados por arquitetura
flutter build apk --release --split-per-abi
```

### Compilação Mais Rápida
```bash
# Usar cache local
flutter build apk --release --build-name=1.0.0 --build-number=1

# Pular testes
flutter build apk --release --no-test-assets
```

## 📊 Verificação de Qualidade

### Análise de Código
```bash
flutter analyze
```

### Testes
```bash
flutter test
```

### Verificação de Dependências
```bash
flutter pub deps
flutter pub outdated
```

## 🔐 Assinatura do APK (Opcional)

Para distribuição profissional:

### 1. Gerar Keystore
```bash
keytool -genkey -v -keystore release-key.keystore -alias key -keyalg RSA -keysize 2048 -validity 10000
```

### 2. Configurar Assinatura
Crie `android/key.properties`:
```properties
storePassword=sua_senha
keyPassword=sua_senha
keyAlias=key
storeFile=../release-key.keystore
```

### 3. Compilar Assinado
```bash
flutter build apk --release
```

## 📋 Checklist Final

- [ ] Flutter doctor sem erros críticos
- [ ] Licenças Android aceitas
- [ ] Java 17 configurado
- [ ] Dependências instaladas (`flutter pub get`)
- [ ] Compilação bem-sucedida
- [ ] APK testado em dispositivo real
- [ ] Permissões funcionando corretamente
- [ ] Monitoramento ativo
- [ ] Webhook Discord funcionando (se configurado)

## 🆘 Suporte Adicional

### Logs de Debug
```bash
# Ver logs durante compilação
flutter build apk --release --verbose

# Ver logs do dispositivo
flutter logs
```

### Informações do Sistema
```bash
flutter doctor -v
flutter --version
```

### Limpeza Completa
```bash
flutter clean
cd android && ./gradlew clean && cd ..
flutter pub get
```

---

**Sucesso na compilação!** 🎉

Se seguir todos os passos corretamente, você terá um APK funcional do Roblox Auto Monitor pronto para instalação e uso.


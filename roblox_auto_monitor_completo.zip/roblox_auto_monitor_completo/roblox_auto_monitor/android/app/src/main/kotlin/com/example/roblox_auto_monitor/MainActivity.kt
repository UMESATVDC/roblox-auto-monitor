package com.example.roblox_auto_monitor

import android.app.ActivityManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.*

class MainActivity: FlutterActivity() {
    private val CHANNEL = "roblox_monitor_native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "isAppRunning" -> {
                    val packageName = call.argument<String>("packageName")
                    if (packageName != null) {
                        val isRunning = isAppRunning(packageName)
                        result.success(isRunning)
                    } else {
                        result.error("INVALID_ARGUMENT", "Package name is required", null)
                    }
                }
                "isAppInForeground" -> {
                    val packageName = call.argument<String>("packageName")
                    if (packageName != null) {
                        val isInForeground = isAppInForeground(packageName)
                        result.success(isInForeground)
                    } else {
                        result.error("INVALID_ARGUMENT", "Package name is required", null)
                    }
                }
                "forceStopApp" -> {
                    val packageName = call.argument<String>("packageName")
                    if (packageName != null) {
                        val success = forceStopApp(packageName)
                        result.success(success)
                    } else {
                        result.error("INVALID_ARGUMENT", "Package name is required", null)
                    }
                }
                "openUsageAccessSettings" -> {
                    openUsageAccessSettings()
                    result.success(true)
                }
                "hasUsageStatsPermission" -> {
                    val hasPermission = hasUsageStatsPermission()
                    result.success(hasPermission)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    private fun isAppRunning(packageName: String): Boolean {
        return try {
            val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val runningProcesses = activityManager.runningAppProcesses
            
            runningProcesses?.any { processInfo ->
                processInfo.processName == packageName
            } ?: false
        } catch (e: Exception) {
            false
        }
    }

    private fun isAppInForeground(packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val currentTime = System.currentTimeMillis()
                val stats = usageStatsManager.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY,
                    currentTime - 1000 * 60, // Últimos 60 segundos
                    currentTime
                )

                if (stats != null && stats.isNotEmpty()) {
                    // Ordenar por último tempo usado
                    val sortedStats = stats.sortedByDescending { it.lastTimeUsed }
                    val mostRecentApp = sortedStats.firstOrNull()
                    
                    return mostRecentApp?.packageName == packageName &&
                            (currentTime - mostRecentApp.lastTimeUsed) < 30000 // Últimos 30 segundos
                }
            } else {
                // Para versões antigas do Android, usar método alternativo
                val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val runningTasks = activityManager.getRunningTasks(1)
                
                if (runningTasks.isNotEmpty()) {
                    val topActivity = runningTasks[0].topActivity
                    return topActivity?.packageName == packageName
                }
            }
            
            false
        } catch (e: Exception) {
            false
        }
    }

    private fun forceStopApp(packageName: String): Boolean {
        return try {
            val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            
            // Método 1: Tentar killBackgroundProcesses
            activityManager.killBackgroundProcesses(packageName)
            
            // Método 2: Tentar via comando shell (pode não funcionar sem root)
            try {
                val process = Runtime.getRuntime().exec("am force-stop $packageName")
                process.waitFor()
            } catch (e: Exception) {
                // Ignorar se falhar
            }
            
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val currentTime = System.currentTimeMillis()
                val stats = usageStatsManager.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY,
                    currentTime - 1000 * 60,
                    currentTime
                )
                return stats != null && stats.isNotEmpty()
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun openUsageAccessSettings() {
        try {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            startActivity(intent)
        } catch (e: Exception) {
            // Fallback para configurações gerais
            val intent = Intent(Settings.ACTION_SETTINGS)
            startActivity(intent)
        }
    }
}


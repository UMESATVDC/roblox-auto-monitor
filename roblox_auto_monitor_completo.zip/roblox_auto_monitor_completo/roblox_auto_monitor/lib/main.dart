import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:permission_handler/permission_handler.dart';
import 'monitoring_service.dart';

void main() {
  runApp(const RobloxAutoMonitorApp());
}

class RobloxAutoMonitorApp extends StatelessWidget {
  const RobloxAutoMonitorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Roblox Auto Monitor',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Roblox Auto Monitor'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  static const MethodChannel _nativeChannel = MethodChannel('roblox_monitor_native');
  
  bool _isMonitoring = false;
  bool _autoStartEnabled = false;
  bool _hasUsageStatsPermission = false;
  String _webhookUrl = '';
  final TextEditingController _webhookController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _checkMonitoringStatus();
    _checkUsageStatsPermission();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _webhookUrl = prefs.getString('webhook_url') ?? '';
      _autoStartEnabled = prefs.getBool('auto_start_enabled') ?? false;
      _webhookController.text = _webhookUrl;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('webhook_url', _webhookUrl);
    await prefs.setBool('auto_start_enabled', _autoStartEnabled);
  }

  Future<void> _checkUsageStatsPermission() async {
    try {
      final hasPermission = await _nativeChannel.invokeMethod('hasUsageStatsPermission');
      setState(() {
        _hasUsageStatsPermission = hasPermission as bool? ?? false;
      });
    } catch (e) {
      print('Erro ao verificar permissão de estatísticas de uso: $e');
      setState(() {
        _hasUsageStatsPermission = false;
      });
    }
  }

  Future<void> _requestUsageStatsPermission() async {
    try {
      await _nativeChannel.invokeMethod('openUsageAccessSettings');
      _showSnackBar('Por favor, conceda a permissão "Estatísticas de Uso" para este app.');
      
      // Verificar novamente após alguns segundos
      Future.delayed(const Duration(seconds: 3), () {
        _checkUsageStatsPermission();
      });
    } catch (e) {
      print('Erro ao abrir configurações de permissão: $e');
      _showSnackBar('Erro ao abrir configurações. Vá manualmente em Configurações > Apps > Acesso especial > Estatísticas de uso.');
    }
  }

  Future<void> _checkMonitoringStatus() async {
    final isRunning = await FlutterForegroundTask.isRunningService;
    setState(() {
      _isMonitoring = isRunning;
    });
  }

  Future<void> _requestPermissions() async {
    // Solicitar permissões necessárias
    await Permission.notification.request();
    await Permission.systemAlertWindow.request();
    
    // Verificar e solicitar permissão de estatísticas de uso se necessário
    if (!_hasUsageStatsPermission) {
      _showPermissionDialog();
    }
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Permissões Necessárias'),
          content: const Text(
            'Este app precisa da permissão "Estatísticas de Uso" para monitorar outros aplicativos. '
            'Esta permissão é essencial para detectar quando o Roblox trava, fecha ou é minimizado.\n\n'
            'Clique em "Abrir Configurações" para conceder esta permissão.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _requestUsageStatsPermission();
              },
              child: const Text('Abrir Configurações'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _startMonitoring() async {
    if (_webhookUrl.isEmpty) {
      _showSnackBar('Por favor, configure a webhook do Discord primeiro.');
      return;
    }

    await _requestPermissions();

    // Configurar o serviço em primeiro plano
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'roblox_monitor_channel',
        channelName: 'Roblox Monitor',
        channelDescription: 'Monitoramento do Roblox em segundo plano',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
        iconData: const NotificationIconData(
          resType: ResourceType.mipmap,
          resPrefix: ResourcePrefix.ic,
          name: 'launcher',
        ),
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: true,
        playSound: false,
      ),
      foregroundTaskOptions: const ForegroundTaskOptions(
        interval: 30000, // 30 segundos
        isOnceEvent: false,
        autoRunOnBoot: true,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );

    // Iniciar o serviço
    final serviceRequestResult = await FlutterForegroundTask.startService(
      notificationTitle: 'Monitorando Roblox...',
      notificationText: 'Verificando status do Roblox a cada 30 segundos',
      callback: startCallback,
    );

    if (serviceRequestResult) {
      setState(() {
        _isMonitoring = true;
      });
      _showSnackBar('Monitoramento iniciado com sucesso!');
    } else {
      _showSnackBar('Erro ao iniciar o monitoramento.');
    }
  }

  Future<void> _stopMonitoring() async {
    final serviceRequestResult = await FlutterForegroundTask.stopService();
    
    if (serviceRequestResult) {
      setState(() {
        _isMonitoring = false;
      });
      _showSnackBar('Monitoramento parado.');
    } else {
      _showSnackBar('Erro ao parar o monitoramento.');
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Status atual
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Icon(
                      _isMonitoring ? Icons.play_circle : Icons.pause_circle,
                      size: 48,
                      color: _isMonitoring ? Colors.green : Colors.grey,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _isMonitoring ? 'Monitorando Roblox...' : 'Monitoramento parado',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _hasUsageStatsPermission ? Icons.check_circle : Icons.warning,
                          color: _hasUsageStatsPermission ? Colors.green : Colors.orange,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _hasUsageStatsPermission 
                            ? 'Permissões OK' 
                            : 'Permissões necessárias',
                          style: TextStyle(
                            color: _hasUsageStatsPermission ? Colors.green : Colors.orange,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Botões de controle
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isMonitoring ? null : _startMonitoring,
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Iniciar Monitoramento'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isMonitoring ? _stopMonitoring : null,
                    icon: const Icon(Icons.stop),
                    label: const Text('Parar Monitoramento'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Campo de webhook
            TextField(
              controller: _webhookController,
              decoration: const InputDecoration(
                labelText: 'Webhook do Discord',
                hintText: 'Cole aqui a URL da webhook do Discord',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.link),
              ),
              onChanged: (value) {
                _webhookUrl = value;
                _saveSettings();
              },
            ),
            const SizedBox(height: 20),

            // Toggle de auto-início
            SwitchListTile(
              title: const Text('Iniciar automaticamente ao ligar o celular'),
              subtitle: const Text('O monitoramento será iniciado automaticamente'),
              value: _autoStartEnabled,
              onChanged: (bool value) {
                setState(() {
                  _autoStartEnabled = value;
                });
                _saveSettings();
              },
            ),
            const SizedBox(height: 20),

            // Informações adicionais
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Como funciona:',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text('• Verifica o status do Roblox a cada 30 segundos'),
                    Text('• Detecta se o app travou, fechou ou foi minimizado'),
                    Text('• Reinicia automaticamente o Roblox no jogo específico'),
                    Text('• Envia notificação via Discord quando necessário'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Callback para o serviço em primeiro plano
@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(MonitoringTaskHandler());
}


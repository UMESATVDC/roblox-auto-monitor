import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'package:flutter/services.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

class MonitoringTaskHandler extends TaskHandler {
  static const String robloxPackageName = 'com.roblox.client';
  static const String robloxGameUrl = 'roblox://placeID=17687504411';
  static const MethodChannel _nativeChannel = MethodChannel('roblox_monitor_native');
  
  int _consecutiveFailures = 0;
  bool _lastRobloxState = false;
  DateTime _lastSuccessfulCheck = DateTime.now();

  @override
  Future<void> onStart(DateTime timestamp, SendPort? sendPort) async {
    print('Serviço de monitoramento iniciado em: $timestamp');
  }

  @override
  Future<void> onRepeatEvent(DateTime timestamp, SendPort? sendPort) async {
    await _performMonitoringCheck();
  }

  @override
  Future<void> onDestroy(DateTime timestamp, SendPort? sendPort) async {
    print('Serviço de monitoramento finalizado em: $timestamp');
  }

  Future<void> _performMonitoringCheck() async {
    try {
      print('Executando verificação de monitoramento...');
      
      final robloxStatus = await _checkRobloxStatus();
      final currentTime = DateTime.now();
      
      // Verificar se o Roblox está com problemas
      bool hasIssue = false;
      String issueDescription = '';

      if (!robloxStatus['isRunning']) {
        hasIssue = true;
        issueDescription = 'Roblox não está rodando';
      } else if (!robloxStatus['isInForeground']) {
        hasIssue = true;
        issueDescription = 'Roblox foi minimizado';
      } else if (_isRobloxFrozen(currentTime)) {
        hasIssue = true;
        issueDescription = 'Roblox pode estar travado';
      }

      if (hasIssue) {
        _consecutiveFailures++;
        print('Problema detectado: $issueDescription (falhas consecutivas: $_consecutiveFailures)');
        
        // Só tomar ação após 2 verificações consecutivas com problema
        if (_consecutiveFailures >= 2) {
          await _handleRobloxIssue(issueDescription);
          _consecutiveFailures = 0;
        }
      } else {
        _consecutiveFailures = 0;
        _lastSuccessfulCheck = currentTime;
        _lastRobloxState = true;
      }

      // Atualizar notificação
      await _updateNotification(hasIssue ? issueDescription : 'Roblox funcionando normalmente');
      
    } catch (e) {
      print('Erro durante verificação de monitoramento: $e');
    }
  }

  Future<Map<String, dynamic>> _checkRobloxStatus() async {
    try {
      // Verificar se o app está instalado e rodando
      final app = await DeviceApps.getApp(robloxPackageName, includeAppIcon: false);
      bool isInstalled = app != null;
      
      if (!isInstalled) {
        return {
          'isRunning': false,
          'isInForeground': false,
          'isInstalled': false,
        };
      }

      // Verificar se está rodando (método simplificado)
      bool isRunning = await _isAppRunning(robloxPackageName);
      bool isInForeground = await _isAppInForeground(robloxPackageName);

      return {
        'isRunning': isRunning,
        'isInForeground': isInForeground,
        'isInstalled': true,
      };
    } catch (e) {
      print('Erro ao verificar status do Roblox: $e');
      return {
        'isRunning': false,
        'isInForeground': false,
        'isInstalled': false,
      };
    }
  }

  Future<bool> _isAppRunning(String packageName) async {
    try {
      final result = await _nativeChannel.invokeMethod('isAppRunning', {
        'packageName': packageName,
      });
      return result as bool? ?? false;
    } catch (e) {
      print('Erro ao verificar se app está rodando via nativo: $e');
      return false;
    }
  }

  Future<bool> _isAppInForeground(String packageName) async {
    try {
      final result = await _nativeChannel.invokeMethod('isAppInForeground', {
        'packageName': packageName,
      });
      return result as bool? ?? false;
    } catch (e) {
      print('Erro ao verificar se app está em foreground via nativo: $e');
      // Fallback simples
      return await _isAppRunning(packageName);
    }
  }

  bool _isRobloxFrozen(DateTime currentTime) {
    // Considerar travado se não houve verificação bem-sucedida nos últimos 5 minutos
    final timeSinceLastSuccess = currentTime.difference(_lastSuccessfulCheck);
    return timeSinceLastSuccess.inMinutes > 5;
  }

  Future<void> _handleRobloxIssue(String issueDescription) async {
    try {
      print('Tratando problema do Roblox: $issueDescription');
      
      // 1. Tentar fechar o Roblox (force-stop)
      await _forceStopRoblox();
      
      // Aguardar um pouco antes de reabrir
      await Future.delayed(const Duration(seconds: 3));
      
      // 2. Abrir o Roblox no jogo específico
      await _openRobloxGame();
      
      // 3. Enviar notificação para Discord
      await _sendDiscordNotification(issueDescription);
      
      print('Ações corretivas executadas com sucesso');
      
    } catch (e) {
      print('Erro ao executar ações corretivas: $e');
    }
  }

  Future<void> _forceStopRoblox() async {
    try {
      // Usar método nativo primeiro
      final success = await _nativeChannel.invokeMethod('forceStopApp', {
        'packageName': robloxPackageName,
      });
      
      if (success) {
        print('Roblox fechado com sucesso via método nativo');
      } else {
        print('Método nativo falhou, tentando alternativas');
        
        // Fallback: Tentar comando shell
        try {
          final result = await Process.run('am', ['force-stop', robloxPackageName]);
          print('Resultado do force-stop via shell: ${result.stdout}');
        } catch (e) {
          print('Comando shell também falhou: $e');
        }
      }
      
    } catch (e) {
      print('Erro ao tentar fechar Roblox via nativo: $e');
      
      // Último recurso: tentar comando shell diretamente
      try {
        final result = await Process.run('am', ['force-stop', robloxPackageName]);
        print('Resultado do force-stop (fallback): ${result.stdout}');
      } catch (e2) {
        print('Todos os métodos de force-stop falharam: $e2');
      }
    }
  }

  Future<void> _openRobloxGame() async {
    try {
      final uri = Uri.parse(robloxGameUrl);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
        print('Roblox aberto com sucesso no jogo específico');
      } else {
        print('Não foi possível abrir o link do Roblox');
        
        // Fallback: tentar abrir o app normalmente
        final robloxUri = Uri.parse('com.roblox.client://');
        if (await canLaunchUrl(robloxUri)) {
          await launchUrl(robloxUri, mode: LaunchMode.externalApplication);
        }
      }
    } catch (e) {
      print('Erro ao abrir Roblox: $e');
    }
  }

  Future<void> _sendDiscordNotification(String issueDescription) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final webhookUrl = prefs.getString('webhook_url');
      
      if (webhookUrl == null || webhookUrl.isEmpty) {
        print('Webhook não configurada, pulando notificação Discord');
        return;
      }

      final message = '[Monitor] Roblox $issueDescription! Reiniciei o app.';
      final payload = {
        'content': message,
        'username': 'Roblox Auto Monitor',
      };

      final response = await http.post(
        Uri.parse(webhookUrl),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(payload),
      );

      if (response.statusCode == 204) {
        print('Notificação Discord enviada com sucesso');
      } else {
        print('Erro ao enviar notificação Discord: ${response.statusCode}');
      }
      
    } catch (e) {
      print('Erro ao enviar notificação Discord: $e');
    }
  }

  Future<void> _updateNotification(String status) async {
    try {
      await FlutterForegroundTask.updateService(
        notificationTitle: 'Monitorando Roblox...',
        notificationText: status,
      );
    } catch (e) {
      print('Erro ao atualizar notificação: $e');
    }
  }
}


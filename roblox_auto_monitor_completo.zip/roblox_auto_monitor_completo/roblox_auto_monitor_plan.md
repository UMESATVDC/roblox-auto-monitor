# Plano de Arquitetura e Tecnologia para Roblox Auto Monitor

## 1. Introdução

Este documento detalha o plano de arquitetura e as tecnologias propostas para o desenvolvimento do aplicativo "Roblox Auto Monitor". O objetivo principal é criar um aplicativo Android leve e autônomo capaz de monitorar o status do aplicativo Roblox, tomar ações corretivas (fechar e reabrir o Roblox em um jogo específico) e notificar o usuário via webhook do Discord em caso de problemas. O aplicativo também deve oferecer uma interface de usuário simples para controle e configuração.

## 2. Escolha da Tecnologia: Flutter

Após análise dos requisitos e das opções de desenvolvimento (Kivy, Flutter, Nativo), o **Flutter** foi selecionado como a tecnologia principal. As razões para essa escolha incluem:

*   **Desenvolvimento Multiplataforma**: Embora o foco inicial seja Android, o Flutter permite o desenvolvimento para iOS e outras plataformas a partir de uma única base de código, o que pode ser uma vantagem futura.
*   **Performance Próxima à Nativa**: O Flutter compila para código nativo, oferecendo excelente desempenho e uma experiência de usuário fluida.
*   **Ecossistema Rico de Pacotes**: A comunidade Flutter é vasta e oferece uma ampla gama de pacotes (plugins) que facilitam a implementação de funcionalidades complexas, como serviços em segundo plano, acesso a informações do sistema e comunicação de rede.
*   **Interface de Usuário Rápida e Flexível**: O Flutter é conhecido por sua capacidade de criar interfaces de usuário bonitas e responsivas com rapidez, o que é ideal para a interface simples e intuitiva solicitada.
*   **Facilidade de Manutenção e Leitura**: A linguagem Dart, utilizada pelo Flutter, é moderna e de fácil aprendizado, o que contribui para um código mais limpo e de fácil manutenção.

## 3. Arquitetura Proposta

A arquitetura do aplicativo será dividida em três componentes principais:

*   **Interface de Usuário (UI)**: Responsável pela interação do usuário, exibição de status e configuração.
*   **Serviço em Primeiro Plano (Foreground Service)**: O núcleo do monitoramento, rodando em segundo plano e garantindo que o Android não encerre o aplicativo. Este serviço será responsável por verificar o status do Roblox e iniciar as ações corretivas.
*   **Lógica de Negócio e Comunicação**: Contém a inteligência para detectar problemas, interagir com o sistema Android (fechar/abrir apps) e enviar mensagens para a webhook do Discord.

### 3.1. Detalhes dos Componentes

#### 3.1.1. Interface de Usuário (UI)

A UI será construída com widgets Flutter padrão. A tela principal incluirá:

*   **Botões de Controle**: "Iniciar monitoramento" e "Parar monitoramento".
*   **Campo de Texto para Webhook**: Um `TextField` para inserir e exibir a URL da webhook do Discord. O valor será salvo localmente (ver Seção 3.1.3).
*   **Toggle de Auto-início**: Um `Switch` para habilitar/desabilitar o início automático do monitoramento ao ligar o celular.
*   **Exibição de Status**: Um `Text` widget para mostrar o status atual do monitoramento (e.g., "Monitorando Roblox...", "Parado").

#### 3.1.2. Serviço em Primeiro Plano (Foreground Service)

Para garantir que o monitoramento funcione continuamente, mesmo com a tela bloqueada ou o aplicativo em segundo plano, será utilizado um **Foreground Service** no Android. Isso é crucial para evitar que o sistema Android encerre o processo do aplicativo para economizar recursos. O pacote `flutter_foreground_task` [1] ou uma implementação nativa via `MethodChannel` será explorado para essa finalidade.

O serviço em primeiro plano será responsável por:

*   Manter uma notificação persistente e discreta ("Monitorando Roblox...").
*   Executar a lógica de monitoramento a cada 30 segundos.
*   Chamar as funções nativas para verificar o status do Roblox.

#### 3.1.3. Lógica de Negócio e Comunicação

Esta camada será responsável por:

*   **Verificação do Status do Roblox**: A detecção de "Roblox foi fechado", "travou/congelou" ou "foi minimizado" é a parte mais complexa. Será necessário interagir com as APIs nativas do Android para obter informações sobre processos em execução e o estado de aplicativos. Pacotes como `appcheck` [2] ou `usage_stats` (requer permissões especiais) podem ser úteis para verificar se o Roblox está rodando. Para detectar travamentos/congelamentos, pode ser necessário verificar o uso da CPU/memória do processo do Roblox ou tentar interagir com a UI do Roblox (o que é mais difícil e pode exigir acesso a APIs de acessibilidade, que podem ser invasivas e exigir permissões adicionais do usuário). Uma abordagem mais simples para travamento pode ser verificar se o processo do Roblox está respondendo ou se o uso de recursos está estático por um período. A detecção de "minimizado" pode ser feita verificando se o Roblox está em primeiro plano.
*   **Ações Corretivas**: 
    *   **Fechar Roblox (force-stop)**: Isso geralmente requer permissões de sistema ou o uso de comandos `am force-stop` via `shell_exec` (o que não é ideal para um APK standalone sem root). Uma alternativa mais viável para aplicativos sem root é usar `ActivityManager.killBackgroundProcesses()` [3], que pode não ser um "force-stop" completo, mas pode ser suficiente para reiniciar o aplicativo. Outra opção é abrir as configurações do aplicativo Roblox para que o usuário possa forçar o fechamento manualmente, mas isso vai contra o requisito de automação. A solução ideal será pesquisada mais a fundo na fase de desenvolvimento.
    *   **Abrir Roblox no jogo específico**: Será utilizado o deep link `roblox://placeID=17687504411`. O pacote `url_launcher` [4] do Flutter é ideal para abrir URLs e deep links.
*   **Persistência de Dados**: A URL da webhook do Discord será salva localmente usando `shared_preferences` [5], um pacote Flutter para armazenamento de dados simples chave-valor.
*   **Comunicação com Discord Webhook**: Será feita uma requisição HTTP POST para a URL da webhook com o corpo da mensagem formatado em JSON. O pacote `http` [6] do Flutter será utilizado para isso.

## 4. Fluxo de Operação

1.  O usuário abre o aplicativo e configura a webhook do Discord e a opção de auto-início.
2.  O usuário clica em "Iniciar monitoramento".
3.  O aplicativo inicia um Foreground Service no Android.
4.  O Foreground Service exibe uma notificação persistente.
5.  A cada 30 segundos, o Foreground Service executa a lógica de monitoramento:
    a.  Verifica o status do aplicativo Roblox (rodando, fechado, travado, minimizado).
    b.  Se um problema for detectado:
        i.   Tenta fechar o Roblox (force-stop).
        ii.  Abre o Roblox usando o deep link para o jogo específico.
        iii. Envia uma mensagem para a webhook do Discord.
6.  Se o usuário desabilitar o monitoramento ou fechar o aplicativo, o Foreground Service é interrompido.
7.  Se a opção de auto-início estiver ativada, o Foreground Service será reiniciado automaticamente após a reinicialização do dispositivo.

## 5. Permissões Necessárias

O aplicativo precisará das seguintes permissões no `AndroidManifest.xml`:

*   `android.permission.INTERNET`: Para enviar mensagens para a webhook do Discord.
*   `android.permission.FOREGROUND_SERVICE`: Para rodar o serviço em primeiro plano.
*   `android.permission.RECEIVE_BOOT_COMPLETED`: Para iniciar o monitoramento automaticamente ao ligar o celular.
*   `android.permission.PACKAGE_USAGE_STATS`: Para verificar o status de outros aplicativos (requer que o usuário conceda essa permissão manualmente nas configurações do Android).
*   `android.permission.KILL_BACKGROUND_PROCESSES`: Para tentar fechar o Roblox (pode não funcionar em todos os dispositivos sem root ou pode ser depreciado em versões mais recentes do Android para apps de terceiros).

## 6. Desafios e Considerações

*   **Detecção de Travamento/Congelamento**: Esta é a parte mais desafiadora sem acesso a APIs de sistema de baixo nível ou root. A detecção pode ser heurística (e.g., verificar se o processo está ativo, mas não há mudança no uso de CPU/memória ou se o aplicativo não está em primeiro plano quando deveria estar). Será necessário testar diferentes abordagens.
*   **"Force-stop" sem Root**: A capacidade de forçar o fechamento de outro aplicativo sem permissões de root é limitada no Android moderno por razões de segurança. `ActivityManager.killBackgroundProcesses()` pode ser a melhor opção disponível para apps sem root, mas seu efeito pode variar. Se não for eficaz, o usuário precisará ser notificado para fechar manualmente ou uma solução alternativa será explorada.
*   **Compatibilidade com Android 7+**: As APIs e permissões podem variar entre as versões do Android. O desenvolvimento será focado em compatibilidade com Android 7 (API 24) e superior.
*   **Tamanho do APK**: O Flutter pode gerar APKs relativamente grandes. Será dada atenção à otimização do tamanho do APK durante o processo de build.

## 7. Próximos Passos

1.  Criação do projeto Flutter.
2.  Implementação da interface de usuário básica.
3.  Integração do pacote `flutter_foreground_task`.
4.  Implementação da lógica de detecção de status do Roblox.
5.  Implementação das ações de fechar e reabrir o Roblox.
6.  Implementação da funcionalidade de webhook do Discord.
7.  Testes exaustivos em diferentes dispositivos Android.

## 8. Referências

[1] `flutter_foreground_task` package: [https://pub.dev/packages/flutter_foreground_task](https://pub.dev/packages/flutter_foreground_task)
[2] `appcheck` package: [https://pub.dev/packages/appcheck](https://pub.dev/packages/appcheck)
[3] `ActivityManager.killBackgroundProcesses()` documentation: [https://developer.android.com/reference/android/app/ActivityManager#killBackgroundProcesses(java.lang.String)](https://developer.android.com/reference/android/app/ActivityManager#killBackgroundProcesses(java.lang.String))
[4] `url_launcher` package: [https://pub.dev/packages/url_launcher](https://pub.dev/packages/url_launcher)
[5] `shared_preferences` package: [https://pub.dev/packages/shared_preferences](https://pub.dev/packages/shared_preferences)
[6] `http` package: [https://pub.dev/packages/http](https://pub.dev/packages/http)


